import * as React from 'react';
import { Label, makeStyles, Radio, RadioGroup, tokens, useId } from '@fluentui/react-components';

export interface IOptionProps {
  text: string;
  key: number;
}

export interface IChoiceAsRadioButtonProps {
  name?: string,
  options: IOptionProps[],
  selectedKey: string | number,
  layout: string,
  onChange: (ev?: React.FormEvent<HTMLElement>, option?: IOptionProps) => void,
}

// const useStyles = makeStyles({
//   field: {
//     display: "grid",
//     gridRowGap: tokens.spacingVerticalS,
//   },
// });

// export class ChoiceAsRadioButton extends React.Component<IChoiceAsRadioButtonProps> {
  
//   public render(): React.ReactNode {

//     const styles = useStyles();
//     const labelId = useId("label");
//     return (
//       <div className={styles.field}>
//         <Label id={this.props.name}>{this.props.name}</Label>
//         <RadioGroup aria-labelledby={labelId}>
//           <Radio value="apple" label="Apple" />
//           <Radio value="pear" label="Pear" />
//           <Radio value="banana" label="Banana" />
//           <Radio value="orange" label="Orange" />
//         </RadioGroup>
//       </div>
//     )
//   }
// }

const useStyles = makeStyles({
  field: {
    display: "table-row-group",
    gridRowGap: tokens.spacingHorizontalS,
  },
});

export const ChoiceAsRadioButton = (props: Partial<IChoiceAsRadioButtonProps>) => {
  const styles = useStyles();
  const labelId = useId("label");
  const layout = props.layout === "vertical" ? "vertical" : "horizontal"
  return (
      <div style={{ display: 'flex', flexDirection: 'row', gap: tokens.spacingHorizontalS }}>
      <Label id={labelId}>{props.name}</Label>
      <RadioGroup aria-labelledby={labelId} layout={layout}>
        {props.options?.map(option => {
          <Radio value={option.key.toString()} label={option.text} />
        })}
      </RadioGroup>
      </div>
  );
};

