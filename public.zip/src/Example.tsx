import {
  RadioGroupProps,
  Label,
  makeStyles,
  Radio,
  RadioGroup,
  tokens,
  useId,
} from "@fluentui/react-components";
import * as React from "react";

const useStyles = makeStyles({
  field: {
    display: "grid",
    gridRowGap: tokens.spacingVerticalS,
  },
});

export const Default = (props: Partial<RadioGroupProps>) => {
  const styles = useStyles();
  const labelId = useId("label");
  const [selectedValue, setSelectedValue] = React.useState<string | undefined>(undefined);

  const handleChange = (ev: React.FormEvent<HTMLElement>, data: { value: string }) => {
    setSelectedValue(data.value);
    console.log("Selected value:", data.value); // This will log the selected value
  };

  return (
    <div className={styles.field}>
      <Label id={labelId}>Choose a fruit:</Label>
      <RadioGroup
        {...props}
        aria-labelledby={labelId}
        layout="horizontal"
        value={selectedValue}
        onChange={handleChange}
      >
        <Radio value="apple" label="Apple" />
        <Radio value="pear" label="Pear" />
        <Radio value="banana" label="Banana" />
        <Radio value="orange" label="Orange" />
      </RadioGroup>
    </div>
  );
};
