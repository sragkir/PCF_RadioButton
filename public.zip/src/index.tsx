import * as ReactDOM from 'react-dom';
import { FluentProvider, webLightTheme } from '@fluentui/react-components';
import { RadioChoiceTypes as Example1, IRadioChoiceProps, IRadioGroupOption } from './ChoiceRadioComponent';
import { Default as Example} from './Example';
//
// You can edit this example in "example.tsx".
//
let _selectedKey:string | number = "";
const sampleChoices: IRadioGroupOption[] = [
  { label: "Option 1", value: "1" },
  { label: "Option 2", value: "2" },
  { label: "Option 3", value: "3" },
];

const props: IRadioChoiceProps = { 
  name: "DisplayName",
  options: sampleChoices, //this._options,
  selectedKey: _selectedKey
};
ReactDOM.render(
    <FluentProvider theme={webLightTheme}>
        <Example1 {...props} />
    </FluentProvider>,
    document.getElementById('root'),
);